"""Create a small, fixed evaluation plan; never submit model requests."""
import copy
import json
from pathlib import Path

root = Path('/opt/evalscope/configs')
root.mkdir(exist_ok=True)
base = {
    'model': 'swift-1.5-abliterated-iq3_s-q8ple',
    'api_url': 'http://10.2.21.4:8080/v1', 'api_key': 'EMPTY',
    'eval_type': 'openai_api', 'eval_batch_size': 2,
    'dataset_hub': 'modelscope', 'seed': 20261014, 'repeats': 1,
    'enable_progress_tracker': True, 'ignore_errors': False, 'debug': False,
    'generation_config': {
        'temperature': 1.0, 'top_p': 0.95, 'seed': 20261014,
        'max_tokens': 16384, 'reasoning_effort': 'high',
        'timeout': 1800, 'retries': 1, 'retry_interval': 5, 'stream': True,
        'extra_body': {'top_k': 20, 'reasoning_budget_tokens': 12288,
                       'chat_template_kwargs': {'enable_thinking': True}},
    },
}
ceval = ['computer_network', 'college_chemistry', 'high_school_biology',
         'college_economics', 'education_science', 'law',
         'chinese_language_and_literature', 'basic_medicine',
         'clinical_medicine', 'accountant']
mmlu = ['chemistry', 'engineering', 'law', 'biology', 'health', 'physics',
        'business', 'philosophy', 'economics', 'other', 'psychology', 'history']
definitions = [
    ('ceval', 8, ceval, 5),
    ('mmlu_pro', 5, mmlu, 5),
    ('ifbench', 60, ['default'], 0),
    ('gpqa_diamond', 40, ['default'], 0),
    ('live_code_bench', 20, ['release_v6'], 0),
    ('bfcl_v4', 10, ['multi_turn_base', 'multi_turn_long_context',
                     'multi_turn_miss_func', 'multi_turn_miss_param'], 0),
]
plan = []
for name, limit, subsets, shots in definitions:
    cfg = copy.deepcopy(base)
    args = {'subset_list': subsets, 'few_shot_num': shots,
            'few_shot_random': False, 'shuffle': name != 'bfcl_v4'}
    cfg.update(datasets=[name], limit=limit, dataset_args={name: args})
    if name in ('gpqa_diamond', 'live_code_bench'):
        cfg['generation_config']['max_tokens'] = 32768
        cfg['generation_config']['extra_body']['reasoning_budget_tokens'] = 24576
    if name == 'live_code_bench':
        args['dataset_id'] = '/opt/evalscope/cache/lcb-fixed/screening'
        args['shuffle'] = False  # Preselected with the same seeded HF permutation; see manifest.
        cfg['sandbox'] = {'enabled': True, 'engine': 'docker', 'pool_size': 1}
        args['sandbox_config'] = {'image': 'python:3.11-slim-bookworm',
                                  'network_enabled': False,
                                  'memory_limit': '1g', 'cpu_limit': 2.0,
                                  'privileged': False, 'volumes': {},
                                  'tools_config': {'shell_executor': {}, 'python_executor': {}}}
    if name == 'bfcl_v4':
        cfg['generation_config']['stream'] = False
        args['extra_params'] = {'is_fc_model': True}
    filename = f'iq3-{name}.json'
    (root / filename).write_text(json.dumps(cfg, indent=2) + '\n')
    plan.append({'config': filename, 'samples': limit * len(subsets),
                 'validated_end_to_end': False})
smoke = copy.deepcopy(base)
smoke.update(datasets=['ceval'], limit=3,
             dataset_args={'ceval': {'subset_list': ['basic_medicine'],
                                    'few_shot_num': 5, 'few_shot_random': False,
                                    'shuffle': True}})
(root / 'smoke-ceval.json').write_text(json.dumps(smoke, indent=2) + '\n')
(root / 'screening-plan.json').write_text(json.dumps({
    'total_samples': sum(x['samples'] for x in plan), 'jobs': plan,
    'note': 'Configuration only. Do not treat saved configs as end-to-end validation. '
            'BFCL uses its own handler: its request-budget forwarding requires a dedicated preflight. '
            'Pin cached datasets and compare sample identities before running another model.'
}, indent=2) + '\n')
print('CONFIGURED', sum(x['samples'] for x in plan), 'formal samples; smoke=3')
