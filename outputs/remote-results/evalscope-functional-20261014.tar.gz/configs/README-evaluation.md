# Fixed qualitative screening

Current model: swift-1.5-abliterated-iq3_s-q8ple; pure text; Strata API http://10.2.21.4:8080/v1.
Formal plan: 300 samples/model. No formal job has been started.

Functional checks completed:
- C-Eval: 3 basic_medicine samples (earlier check).
- BFCL v4: 1 multi_turn_base sample; 18 requests, 23 tool calls, no transport error or truncation, official score 1/1. Inference cache was reused when repairing scoring dependencies.
- LiveCodeBench release_v6: 1 sample, question 1873_A; generated code passed 5/5 test cases in Docker sandbox; report 1/1. This is a pipeline check, not a model capability estimate.

Architecture:
- Dashboard remains in Docker on port 9000.
- Non-code jobs use local/evalscope-worker:1.13.0 via evalscope-bench@.service. BFCL version 2025.10.27.1; CPU-only torch; NumPy 1.26.4 + PyArrow 21.0.0; soundfile included for upstream Qwen-Agent import.
- Code jobs use the host .sandbox-venv evaluation driver via evalscope-code@.service. Generated code runs only in temporary Docker containers: network none, no host mounts, not privileged, CPU quota 2 cores, memory 1 GiB, testcase timeout 6 seconds. No Docker socket is exposed to dashboard or worker containers.
- BFCL request transport explicitly forwards generation policy and writes parameter/status-only request-audit.jsonl. Benchmark prompts, tool simulation and scoring remain upstream.
- All jobs share a lock, assert the expected loaded pure-text model, save persistent state and fail on transport/infrastructure errors. No job is enabled at boot.

LiveCodeBench full Parquet conversion exhausted this 3.3-GiB VM's RAM. Instead, cache/lcb-fixed/screening contains 20 unchanged source records selected by the same seeded HF permutation (seed 20261014) from 1055 release_v6 rows. manifest.json records source URLs, shard hashes, indices, IDs and JSONL hash. Explicit string features preserve contest_date typing. This cache is reused for model comparisons. Initial preparation used temporary disk swap; normal fixed-sample jobs do not repeat preparation.

Examples for a later authorized run (these commands have NOT been executed for formal jobs):
  systemctl start evalscope-bench@iq3-ceval
  systemctl start evalscope-bench@iq3-bfcl_v4
  systemctl start evalscope-code@iq3-live_code_bench

Status: systemctl status evalscope-bench@JOB or evalscope-code@JOB
Logs: journalctl -u evalscope-bench@JOB (or evalscope-code@JOB)
Outputs: /opt/evalscope/outputs/jobs/JOB/
Dashboard: http://10.2.23.3:9000
Keep failed smoke-code directories as diagnostics; smoke-code-fixed is the successful code check.
