"""Run exactly one explicitly selected EvalScope job with persistent state."""
import datetime
import fcntl
import hashlib
import json
import os
import pathlib
import sys
import urllib.request

from evalscope import TaskConfig, run_task

name = sys.argv[1]
allowed = {'smoke-ceval', 'iq3-ceval', 'iq3-mmlu_pro', 'iq3-ifbench',
           'iq3-gpqa_diamond', 'iq3-live_code_bench', 'iq3-bfcl_v4',
           'smoke-bfcl', 'smoke-code', 'smoke-code-fixed'}
if name not in allowed:
    raise SystemExit('Unknown job name')
workspace = pathlib.Path(os.environ.get('EVALSCOPE_WORKSPACE', '/workspace'))
config_path = workspace / 'configs' / (name + '.json')
raw = config_path.read_bytes()
cfg = json.loads(raw)
if 'live_code_bench' in cfg['datasets']:
    assert cfg.get('sandbox', {}).get('enabled') is True, 'Code benchmark requires sandbox'
    assert cfg['sandbox']['engine'] == 'docker'
    sandbox_cfg = cfg['dataset_args']['live_code_bench']['sandbox_config']
    assert sandbox_cfg.get('network_enabled') is False
    assert not sandbox_cfg.get('volumes') and not sandbox_cfg.get('privileged')
out = workspace / 'outputs/jobs' / name
out.mkdir(parents=True, exist_ok=True)
lock = (out.parent / '.evaluation.lock').open('w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
identity = hashlib.sha256(raw).hexdigest()
state_path = out / 'job-state.json'
old = json.loads(state_path.read_text()) if state_path.exists() else {}
if old and old.get('config_sha256') != identity:
    raise SystemExit('Config changed: use a new job name/output directory')
state = {'job': name, 'config_sha256': identity,
         'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'status': 'starting', 'expected_model': cfg['model']}

def save():
    tmp = state_path.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, indent=2) + '\n')
    tmp.replace(state_path)

try:
    save()
    with urllib.request.urlopen(cfg['api_url'].removesuffix('/v1') + '/health', timeout=15) as r:
        health = json.load(r)
    assert health['loaded'] and health['model'] == cfg['model'] and not health['images'], health
    cfg.update(work_dir=str(out / 'evaluation'), no_timestamp=True)
    if any((out / 'evaluation').rglob('*.jsonl')):
        cfg['use_cache'] = str(out / 'evaluation')
    task = TaskConfig(**cfg)
    bfcl_stats = None
    if 'bfcl_v4' in cfg['datasets']:
        from bfcl_policy import install_policy
        bfcl_stats = install_policy(cfg['generation_config'], out / 'request-audit.jsonl')
    state['status'] = 'running'
    save()
    run_task(task_cfg=task)
    if bfcl_stats is not None:
        state['bfcl_transport'] = bfcl_stats
        assert bfcl_stats['requests'] > 0 or cfg.get('use_cache'), 'BFCL made no requests'
        assert bfcl_stats['errors'] == 0, 'BFCL transport errors; score is not valid'
        assert bfcl_stats['truncated'] == 0, 'BFCL output budget exhausted; inspect before scoring'
    reports = list((out / 'evaluation' / 'reports').rglob('*.json'))
    assert reports, 'No scored report produced'
    for report in reports:
        summary = json.loads(report.read_text()).get('execution_summary', {})
        assert not summary.get('incomplete'), 'Incomplete benchmark execution'
        assert not summary.get('errored', 0), 'Benchmark samples errored'
    if 'live_code_bench' in cfg['datasets']:
        reviewed = 0
        for review in (out / 'evaluation' / 'reviews').rglob('*.jsonl'):
            for line in review.read_text().splitlines():
                score = json.loads(line)['sample_score']['score']
                metadata = score.get('metadata', {})
                assert metadata.get('execution_method') == 'sandbox', 'Code executed without sandbox'
                assert not metadata.get('error'), metadata.get('error')
                details = metadata.get('detailed_results', {})
                assert not details.get('error'), details.get('error')
                assert details.get('total_tests', 0) > 0, 'Sandbox executed no test cases'
                reviewed += 1
        assert reviewed, 'No code execution reviews found'
    state.update(status='completed', reports=[str(x) for x in reports])
except BaseException as e:
    state.update(status='failed', error_type=type(e).__name__, error=str(e))
    raise
finally:
    state['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
