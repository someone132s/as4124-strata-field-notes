"""Forward the selected generation policy through BFCL's separate SDK handler.

This changes request transport only; benchmark prompts and scoring stay upstream.
"""
import json
import threading
import time


def install_policy(generation, audit_path):
    from bfcl_eval.model_handler.api_inference.openai_completion import OpenAICompletionsHandler

    original_init = OpenAICompletionsHandler.__init__
    original_generate = OpenAICompletionsHandler.generate_with_backoff
    lock = threading.Lock()
    stats = {'requests': 0, 'errors': 0, 'truncated': 0, 'tool_calls': 0}

    def init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        self.client = self.client.with_options(
            timeout=generation.get('timeout', 1800),
            max_retries=generation.get('retries', 1))

    def generate(self, **kwargs):
        for key in ('temperature', 'top_p', 'seed', 'max_tokens', 'reasoning_effort'):
            if key in generation:
                kwargs[key] = generation[key]
        kwargs['extra_body'] = dict(generation.get('extra_body', {}))
        kwargs['stream'] = False
        record = {'policy': {k: v for k, v in kwargs.items()
                             if k not in ('messages', 'tools')},
                  'message_count': len(kwargs.get('messages', [])),
                  'tool_count': len(kwargs.get('tools', []))}
        start = time.monotonic()
        try:
            response, latency = original_generate(self, **kwargs)
            record.update(finish_reason=response.choices[0].finish_reason,
                          usage=response.usage.model_dump() if response.usage else None,
                          tool_calls=len(response.choices[0].message.tool_calls or []))
            with lock:
                stats['truncated'] += record['finish_reason'] == 'length'
                stats['tool_calls'] += record['tool_calls']
            return response, latency
        except Exception as exc:
            record.update(error_type=type(exc).__name__, error=str(exc)[:1000])
            with lock:
                stats['errors'] += 1
            raise
        finally:
            record['elapsed_seconds'] = round(time.monotonic() - start, 3)
            with lock:
                stats['requests'] += 1
                with audit_path.open('a') as stream:
                    stream.write(json.dumps(record) + '\n')

    OpenAICompletionsHandler.__init__ = init
    OpenAICompletionsHandler.generate_with_backoff = generate
    return stats
