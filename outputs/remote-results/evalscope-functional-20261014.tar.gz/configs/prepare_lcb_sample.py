import json,pathlib,re,hashlib
import numpy as np
import pyarrow.parquet as pq
root=pathlib.Path('/opt/evalscope');cache=root/'cache/modelscope/datasets/downloads';files=[]
for meta in cache.glob('*.json'):
 d=json.loads(meta.read_text());url=d.get('url','')
 if 'livecodebench_code_generation_lite_parquet' in url and 'release_v6' in url:
  source=meta.with_suffix('');idx=int(re.search(r'test-(\d+)-of-',url).group(1));files.append((idx,source,url))
files.sort();assert len(files)==9
sizes=[pq.ParquetFile(p).metadata.num_rows for _,p,_ in files];total=sum(sizes)
selected=list(map(int,np.random.default_rng(20261014).permutation(total)[:20]));wanted=set(selected)|{0};records={};offset=0;manifest=[]
for (idx,path,url),count in zip(files,sizes):
 indices={i-offset for i in wanted if offset<=i<offset+count}
 if indices:
  pf=pq.ParquetFile(path,pre_buffer=False)
  for row,batch in enumerate(pf.iter_batches(batch_size=1,use_threads=False)):
   if row in indices:
    record=batch.to_pylist()[0];records[offset+row]=record
    if len([i for i in indices if offset+i in records])==len(indices):break
  manifest.append({'shard':idx,'url':url,'bytes':path.stat().st_size,'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest()})
 offset+=count
out=root/'cache/lcb-fixed';out.mkdir(exist_ok=True)
for name,indices in [('smoke',[0]),('screening',selected)]:
 folder=out/name;folder.mkdir(exist_ok=True)
 data=''.join(json.dumps(records[i],ensure_ascii=False,default=str)+'\n' for i in indices)
 (folder/'test.jsonl').write_text(data)
 (folder/'README.md').write_text('---\ndataset_info:\n  config_name: release_v6\n  features:\n'+''.join('  - name: '+key+'\n    dtype: string\n' for key in records[indices[0]])+'configs:\n- config_name: release_v6\n  data_files:\n  - split: test\n    path: test.jsonl\n---\n')
 (folder/'manifest.json').write_text(json.dumps({'source':'evalscope/livecodebench_code_generation_lite_parquet','subset':'release_v6','total_original_rows':total,'seed':20261014,'indices':indices,'question_ids':[records[i].get('question_id') for i in indices],'jsonl_sha256':hashlib.sha256(data.encode()).hexdigest(),'source_shards':manifest},indent=2))
 print(name,len(indices),[records[i].get('question_id') for i in indices],flush=True)
import resource; print("PEAK_RSS_KB",resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,flush=True)
